from app.vault_runtime.voice.openai_realtime import OpenAIRealtimeProvider
from app.vault_runtime.voice.provider import ProviderCredential, RealtimeSessionRequest


def test_openai_realtime_uses_owner_credential_and_donor_payload() -> None:
    captured = {}

    def transport(url, headers, payload):
        captured.update(url=url, headers=headers, payload=payload)
        return {"id": "provider-session", "value": "ephemeral", "expires_at": 123}

    provider = OpenAIRealtimeProvider(json_transport=transport)
    result = provider.create_realtime_session(
        RealtimeSessionRequest(
            model_key="gpt-realtime", connection_mode="webrtc",
            instructions="Local scoped instructions.", voice="alloy",
            tool_definitions=({
                "type": "function", "name": "memory_lookup", "description": "Look up memory.",
                "parameters": {"type": "object", "properties": {}},
            },),
            input_audio_transcription_model="gpt-4o-mini-transcribe",
            turn_detection_type="server_vad", turn_detection_create_response=True,
            turn_detection_interrupt_response=False,
            audio_format="audio/pcm", audio_rate=24_000,
            input_noise_reduction_type="near_field",
            turn_detection_threshold=0.92,
            turn_detection_prefix_padding_ms=500,
            turn_detection_silence_duration_ms=1_200,
            tool_choice="auto",
        ),
        credential=ProviderCredential("owner-secret"),
    )
    assert captured["url"] == "https://api.openai.com/v1/realtime/client_secrets"
    assert captured["headers"]["Authorization"] == "Bearer owner-secret"
    assert "owner-secret" not in str(captured["payload"])
    assert captured["payload"]["session"]["tools"][0]["name"] == "memory_lookup"
    session = captured["payload"]["session"]
    assert session["audio"]["input"]["format"] == {"type": "audio/pcm", "rate": 24_000}
    assert session["audio"]["input"]["noise_reduction"] == {"type": "near_field"}
    assert session["audio"]["input"]["turn_detection"] == {
        "type": "server_vad", "create_response": True, "interrupt_response": False,
        "threshold": 0.92, "prefix_padding_ms": 500, "silence_duration_ms": 1_200,
    }
    assert session["tool_choice"] == "auto"
    assert result.client_secret == "ephemeral" and result.provider_session_id == "provider-session"


def test_chatgpt_oauth_exchanges_browser_offer_for_answer(monkeypatch) -> None:
    captured = {}

    class Response:
        text = "v=0\r\no=answer"

        @staticmethod
        def raise_for_status():
            return None

    def post(url, **kwargs):
        captured.update(url=url, **kwargs)
        return Response()

    monkeypatch.setattr("app.vault_runtime.voice.openai_realtime.httpx.post", post)
    result = OpenAIRealtimeProvider().create_realtime_session(
        RealtimeSessionRequest(
            model_key="gpt-live-1", connection_mode="webrtc",
            instructions="Vault context.", voice="sol", offer_sdp="v=0\r\no=offer",
        ),
        credential=ProviderCredential("oauth-token", auth_method="chatgpt_oauth"),
    )
    assert captured["url"] == "https://chatgpt.com/backend-api/codex/realtime/calls"
    assert captured["headers"]["Authorization"] == "Bearer oauth-token"
    assert captured["json"]["sdp"].startswith("v=0")
    assert result.sdp_answer.startswith("v=0") and result.client_secret is None
