from pathlib import Path

import pytest

from app.vault_runtime.extensions.filesystem import ExtensionFilesystem, ExtensionFilesystemError


def _candidate(root: Path, name: str, content: str) -> Path:
    candidate = root / name
    candidate.mkdir()
    (candidate / "SKILL.md").write_text(content, encoding="utf-8")
    return candidate


def test_replace_preserves_previous_and_rollback_swaps_versions(tmp_path: Path) -> None:
    filesystem = ExtensionFilesystem(tmp_path / "extensions")
    first = filesystem.replace(category="skills", identity="demo", candidate_root=_candidate(tmp_path, "one", "one"))
    assert (first.current / "SKILL.md").read_text() == "one"
    second = filesystem.replace(category="skills", identity="demo", candidate_root=_candidate(tmp_path, "two", "two"))
    assert (second.current / "SKILL.md").read_text() == "two"
    assert second.previous and (second.previous / "SKILL.md").read_text() == "one"
    rolled = filesystem.rollback(category="skills", identity="demo")
    assert (rolled.current / "SKILL.md").read_text() == "one"
    assert rolled.previous and (rolled.previous / "SKILL.md").read_text() == "two"


def test_filesystem_rejects_unsafe_identity_and_missing_previous(tmp_path: Path) -> None:
    filesystem = ExtensionFilesystem(tmp_path / "extensions")
    candidate = _candidate(tmp_path, "one", "one")
    with pytest.raises(ExtensionFilesystemError, match="unsafe"):
        filesystem.replace(category="skills", identity="../escape", candidate_root=candidate)
    with pytest.raises(ExtensionFilesystemError, match="no previous"):
        filesystem.rollback(category="skills", identity="demo")


def test_recover_restores_previous_after_interrupted_move(tmp_path: Path) -> None:
    extensions = tmp_path / "extensions"
    base = extensions / "skills" / "demo"
    previous = base / "previous"
    previous.mkdir(parents=True)
    (previous / "SKILL.md").write_text("stable", encoding="utf-8")
    staged = base / ".staged-op1"
    staged.mkdir()
    recovery = extensions / "recovery"
    recovery.mkdir()
    (recovery / "op1.json").write_text(
        '{"operationId":"op1","category":"skills","identity":"demo","state":"previous-moved","hadCurrent":true}',
        encoding="utf-8",
    )
    assert ExtensionFilesystem(extensions).recover() == ("op1",)
    assert (base / "current" / "SKILL.md").read_text() == "stable"
    assert not staged.exists()
    assert not (recovery / "op1.json").exists()
