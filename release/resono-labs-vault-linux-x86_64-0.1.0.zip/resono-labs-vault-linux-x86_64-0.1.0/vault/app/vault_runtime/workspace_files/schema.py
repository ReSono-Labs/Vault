from __future__ import annotations

SCHEMA_STATEMENTS: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS vault_private.vault_workspace_file_projections (
      workspace_file_projection_id text PRIMARY KEY,
      workspace_id text NOT NULL REFERENCES vault_private.local_workspaces(workspace_id) ON DELETE CASCADE,
      file_key text NOT NULL,
      file_key_hash text NOT NULL,
      entry_kind text NOT NULL CHECK (entry_kind IN ('file', 'directory')),
      mime_type text,
      content_ref text,
      content_hash text NOT NULL,
      content_markdown text NOT NULL DEFAULT '',
      content_bytes bytea,
      projection_version integer NOT NULL DEFAULT 1 CHECK (projection_version >= 1),
      generated_at timestamptz NOT NULL DEFAULT now(),
      last_applied_at timestamptz,
      updated_at timestamptz NOT NULL DEFAULT now(),
      UNIQUE (workspace_id, file_key_hash)
    )
    """,
    """
    CREATE INDEX IF NOT EXISTS ix_vault_workspace_file_projections_workspace_key
    ON vault_private.vault_workspace_file_projections (workspace_id, file_key)
    """,
    """
    CREATE TABLE IF NOT EXISTS vault_private.vault_workspace_folder_shares (
      share_id text PRIMARY KEY,
      workspace_id text NOT NULL REFERENCES vault_private.local_workspaces(workspace_id) ON DELETE CASCADE,
      folder_path text NOT NULL,
      folder_path_hash text NOT NULL,
      grantee_user_id text NOT NULL REFERENCES vault_private.local_users(user_id) ON DELETE CASCADE,
      permission text NOT NULL CHECK (permission IN ('read', 'write')),
      created_by_user_id text NOT NULL REFERENCES vault_private.local_users(user_id) ON DELETE RESTRICT,
      status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'revoked')),
      created_at timestamptz NOT NULL DEFAULT now(),
      revoked_at timestamptz,
      UNIQUE (workspace_id, folder_path_hash, grantee_user_id)
    )
    """,
    """
    CREATE INDEX IF NOT EXISTS ix_vault_workspace_folder_shares_grantee
    ON vault_private.vault_workspace_folder_shares (grantee_user_id, status)
    """,
)
