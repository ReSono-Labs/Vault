from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from hashlib import sha256
from pathlib import PurePosixPath
from typing import Any
from uuid import uuid4

import psycopg

from app.vault_runtime.workspace_files.errors import (
    WorkspaceFileBadRequestError,
    WorkspaceFileNotFoundError,
)
from app.vault_runtime.workspace_files.schema import SCHEMA_STATEMENTS
from app.vault_runtime.workspace_paths import (
    normalize_workspace_file_key,
    normalize_workspace_file_prefix,
)

RESERVED_WORKSPACE_FILE_KEYS = frozenset(
    {
        "DEVICE_FAMILY.md",
        "MEMORY.md",
        "SANDBOX.md",
        "TOOLS.md",
        "USER.md",
        "WORKSPACE.md",
    }
)


def workspace_file_key_hash(file_key: str) -> str:
    return sha256(file_key.encode("utf-8")).hexdigest()


def is_reserved_workspace_file_key(file_key: str) -> bool:
    try:
        normalized = normalize_workspace_file_key(file_key, require_extension=False)
    except ValueError:
        return False
    return normalized in RESERVED_WORKSPACE_FILE_KEYS


def normalize_workspace_file_entry_kind(entry_kind: str) -> str:
    normalized = (entry_kind or "").strip().lower()
    if normalized not in {"file", "directory"}:
        raise WorkspaceFileBadRequestError("Workspace file entry kind is invalid.")
    return normalized


@dataclass(frozen=True, slots=True)
class WorkspaceFileProjection:
    workspace_file_projection_id: str
    workspace_id: str
    file_key: str
    file_key_hash: str
    entry_kind: str
    mime_type: str | None
    content_ref: str | None
    content_hash: str
    content_markdown: str
    content_bytes: bytes | None
    projection_version: int
    generated_at: datetime
    last_applied_at: datetime | None
    updated_at: datetime


@dataclass(frozen=True, slots=True)
class WorkspaceFolderShare:
    share_id: str
    workspace_id: str
    folder_path: str
    grantee_user_id: str
    permission: str
    created_by_user_id: str
    status: str
    grantee_display_name: str | None = None
    grantee_username: str | None = None
    owner_display_name: str | None = None


def _row_to_projection(row: tuple[Any, ...]) -> WorkspaceFileProjection:
    return WorkspaceFileProjection(
        workspace_file_projection_id=str(row[0]),
        workspace_id=str(row[1]),
        file_key=str(row[2]),
        file_key_hash=str(row[3]),
        entry_kind=str(row[4]),
        mime_type=str(row[5]) if row[5] is not None else None,
        content_ref=str(row[6]) if row[6] is not None else None,
        content_hash=str(row[7]),
        content_markdown=str(row[8] or ""),
        content_bytes=bytes(row[9]) if row[9] is not None else None,
        projection_version=int(row[10]),
        generated_at=row[11],
        last_applied_at=row[12],
        updated_at=row[13],
    )


_PROJECTION_COLUMNS = """
  workspace_file_projection_id, workspace_id, file_key, file_key_hash, entry_kind,
  mime_type, content_ref, content_hash, content_markdown, content_bytes,
  projection_version, generated_at, last_applied_at, updated_at
"""


class WorkspaceFileRepository:
    def __init__(self, *, database_url: str) -> None:
        self._database_url = database_url

    def ensure_schema(self) -> None:
        with psycopg.connect(self._database_url, connect_timeout=5) as connection:
            with connection.cursor() as cursor:
                for statement in SCHEMA_STATEMENTS:
                    cursor.execute(statement)
            connection.commit()

    def get_projection(self, *, workspace_id: str, file_key: str) -> WorkspaceFileProjection | None:
        normalized = normalize_workspace_file_key(file_key)
        with psycopg.connect(self._database_url, connect_timeout=5) as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    f"""
                    SELECT {_PROJECTION_COLUMNS}
                    FROM vault_private.vault_workspace_file_projections
                    WHERE workspace_id = %s AND file_key_hash = %s AND file_key = %s
                    """,
                    (workspace_id, workspace_file_key_hash(normalized), normalized),
                )
                row = cursor.fetchone()
        return _row_to_projection(row) if row else None

    def list_under_prefix(self, *, workspace_id: str, prefix: str | None) -> list[WorkspaceFileProjection]:
        normalized_prefix = normalize_workspace_file_prefix(prefix)
        query = f"""
            SELECT {_PROJECTION_COLUMNS}
            FROM vault_private.vault_workspace_file_projections
            WHERE workspace_id = %s
        """
        params: list[Any] = [workspace_id]
        if normalized_prefix:
            query += " AND (file_key = %s OR file_key LIKE %s)"
            params.extend((normalized_prefix, f"{normalized_prefix}/%"))
        query += " ORDER BY file_key ASC"
        with psycopg.connect(self._database_url, connect_timeout=5) as connection:
            with connection.cursor() as cursor:
                cursor.execute(query, params)
                rows = cursor.fetchall()
        return [_row_to_projection(row) for row in rows]

    def upsert_projection(
        self,
        *,
        workspace_id: str,
        file_key: str,
        content_markdown: str,
        content_bytes: bytes | None = None,
        content_ref: str | None = None,
        entry_kind: str = "file",
        mime_type: str | None = "text/markdown",
    ) -> WorkspaceFileProjection:
        normalized_key = normalize_workspace_file_key(file_key)
        normalized_kind = normalize_workspace_file_entry_kind(entry_kind)
        payload = content_bytes if content_bytes is not None else content_markdown.encode("utf-8")
        content_hash = sha256(payload).hexdigest()
        with psycopg.connect(self._database_url, connect_timeout=5) as connection:
            with connection.cursor() as cursor:
                existing = self._get_projection_cursor(
                    cursor, workspace_id=workspace_id, file_key=normalized_key,
                )
                if existing is None:
                    cursor.execute(
                        f"""
                        INSERT INTO vault_private.vault_workspace_file_projections (
                          workspace_file_projection_id, workspace_id, file_key, file_key_hash,
                          entry_kind, mime_type, content_ref, content_hash, content_markdown,
                          content_bytes, projection_version, generated_at, last_applied_at, updated_at
                        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 1, now(), now(), now())
                        RETURNING {_PROJECTION_COLUMNS}
                        """,
                        (
                            str(uuid4()), workspace_id, normalized_key,
                            workspace_file_key_hash(normalized_key), normalized_kind, mime_type,
                            content_ref, content_hash, content_markdown, content_bytes,
                        ),
                    )
                else:
                    version = existing.projection_version + (
                        1 if existing.content_hash != content_hash else 0
                    )
                    cursor.execute(
                        f"""
                        UPDATE vault_private.vault_workspace_file_projections
                        SET entry_kind = %s, mime_type = %s, content_ref = %s, content_hash = %s,
                            content_markdown = %s, content_bytes = %s,
                            projection_version = %s, generated_at = now(), last_applied_at = now(),
                            updated_at = now()
                        WHERE workspace_file_projection_id = %s
                        RETURNING {_PROJECTION_COLUMNS}
                        """,
                        (
                            normalized_kind, mime_type, content_ref, content_hash,
                            content_markdown, content_bytes, version,
                            existing.workspace_file_projection_id,
                        ),
                    )
                row = cursor.fetchone()
            connection.commit()
        if row is None:
            raise WorkspaceFileNotFoundError("Workspace file projection could not be saved.")
        return _row_to_projection(row)

    def update_projection(
        self,
        *,
        projection: WorkspaceFileProjection,
        file_key: str | None = None,
        content_markdown: str | None = None,
        content_bytes: bytes | None = None,
        mime_type: str | None = None,
    ) -> WorkspaceFileProjection:
        next_key = normalize_workspace_file_key(file_key) if file_key is not None else projection.file_key
        next_markdown = projection.content_markdown if content_markdown is None else content_markdown
        next_bytes = projection.content_bytes if content_bytes is None else content_bytes
        payload = next_bytes if next_bytes is not None else next_markdown.encode("utf-8")
        content_hash = sha256(payload).hexdigest()
        version = projection.projection_version + (1 if projection.content_hash != content_hash else 0)
        with psycopg.connect(self._database_url, connect_timeout=5) as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    f"""
                    UPDATE vault_private.vault_workspace_file_projections
                    SET file_key = %s, file_key_hash = %s, content_markdown = %s, content_bytes = %s,
                        content_hash = %s, mime_type = COALESCE(%s, mime_type),
                        projection_version = %s, last_applied_at = now(), updated_at = now()
                    WHERE workspace_file_projection_id = %s
                    RETURNING {_PROJECTION_COLUMNS}
                    """,
                    (
                        next_key, workspace_file_key_hash(next_key), next_markdown, next_bytes,
                        content_hash, mime_type, version, projection.workspace_file_projection_id,
                    ),
                )
                row = cursor.fetchone()
            connection.commit()
        if row is None:
            raise WorkspaceFileNotFoundError("Workspace file projection could not be updated.")
        return _row_to_projection(row)

    def delete_projection(self, *, projection: WorkspaceFileProjection) -> None:
        with psycopg.connect(self._database_url, connect_timeout=5) as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    "DELETE FROM vault_private.vault_workspace_file_projections WHERE workspace_file_projection_id = %s",
                    (projection.workspace_file_projection_id,),
                )
            connection.commit()

    def list_shares_for_folder(
        self, *, workspace_id: str, folder_path: str, actor_user_id: str,
    ) -> list[WorkspaceFolderShare]:
        normalized = normalize_workspace_file_prefix(folder_path)
        with psycopg.connect(self._database_url, connect_timeout=5) as connection:
            with connection.cursor() as cursor:
                self._require_owner_cursor(cursor, user_id=actor_user_id, workspace_id=workspace_id)
                cursor.execute(
                    """
                    SELECT s.share_id, s.workspace_id, s.folder_path, s.grantee_user_id, s.permission,
                           s.created_by_user_id, s.status, u.display_name, u.username_normalized
                    FROM vault_private.vault_workspace_folder_shares s
                    JOIN vault_private.local_users u ON u.user_id = s.grantee_user_id
                    WHERE s.workspace_id = %s AND s.folder_path_hash = %s AND s.status = 'active'
                    ORDER BY u.display_name, u.username_normalized
                    """,
                    (workspace_id, workspace_file_key_hash(normalized)),
                )
                rows = cursor.fetchall()
        return [
            WorkspaceFolderShare(
                share_id=str(row[0]), workspace_id=str(row[1]), folder_path=str(row[2]),
                grantee_user_id=str(row[3]), permission=str(row[4]), created_by_user_id=str(row[5]),
                status=str(row[6]), grantee_display_name=str(row[7]), grantee_username=str(row[8]),
            )
            for row in rows
        ]

    def list_shares_for_grantee(self, *, grantee_user_id: str) -> list[WorkspaceFolderShare]:
        with psycopg.connect(self._database_url, connect_timeout=5) as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT s.share_id, s.workspace_id, s.folder_path, s.grantee_user_id, s.permission,
                           s.created_by_user_id, s.status, grantee.display_name, grantee.username_normalized,
                           owner.display_name
                    FROM vault_private.vault_workspace_folder_shares s
                    JOIN vault_private.local_users grantee ON grantee.user_id = s.grantee_user_id
                    JOIN vault_private.local_workspaces w ON w.workspace_id = s.workspace_id
                    JOIN vault_private.local_users owner ON owner.user_id = w.owner_user_id
                    WHERE s.grantee_user_id = %s AND s.status = 'active'
                    ORDER BY owner.display_name, s.folder_path
                    """,
                    (grantee_user_id,),
                )
                rows = cursor.fetchall()
        return [
            WorkspaceFolderShare(
                share_id=str(row[0]), workspace_id=str(row[1]), folder_path=str(row[2]),
                grantee_user_id=str(row[3]), permission=str(row[4]), created_by_user_id=str(row[5]),
                status=str(row[6]), grantee_display_name=str(row[7]), grantee_username=str(row[8]),
                owner_display_name=str(row[9]),
            )
            for row in rows
        ]

    def get_share(self, *, share_id: str, grantee_user_id: str | None = None) -> WorkspaceFolderShare | None:
        query = """
            SELECT s.share_id, s.workspace_id, s.folder_path, s.grantee_user_id, s.permission,
                   s.created_by_user_id, s.status, grantee.display_name, grantee.username_normalized,
                   owner.display_name
            FROM vault_private.vault_workspace_folder_shares s
            JOIN vault_private.local_users grantee ON grantee.user_id = s.grantee_user_id
            JOIN vault_private.local_workspaces w ON w.workspace_id = s.workspace_id
            JOIN vault_private.local_users owner ON owner.user_id = w.owner_user_id
            WHERE s.share_id = %s AND s.status = 'active'
        """
        params: list[Any] = [share_id]
        if grantee_user_id is not None:
            query += " AND s.grantee_user_id = %s"
            params.append(grantee_user_id)
        with psycopg.connect(self._database_url, connect_timeout=5) as connection:
            with connection.cursor() as cursor:
                cursor.execute(query, params)
                row = cursor.fetchone()
        if row is None:
            return None
        return WorkspaceFolderShare(
            share_id=str(row[0]), workspace_id=str(row[1]), folder_path=str(row[2]),
            grantee_user_id=str(row[3]), permission=str(row[4]), created_by_user_id=str(row[5]),
            status=str(row[6]), grantee_display_name=str(row[7]), grantee_username=str(row[8]),
            owner_display_name=str(row[9]),
        )

    def upsert_share(
        self,
        *,
        workspace_id: str,
        folder_path: str,
        grantee_user_id: str,
        permission: str,
        created_by_user_id: str,
    ) -> WorkspaceFolderShare:
        if permission not in {"read", "write"}:
            raise WorkspaceFileBadRequestError("Share permission must be read or write.")
        normalized = normalize_workspace_file_prefix(folder_path)
        if not normalized:
            raise WorkspaceFileBadRequestError("A folder path is required to share.")
        with psycopg.connect(self._database_url, connect_timeout=5) as connection:
            with connection.cursor() as cursor:
                self._require_owner_cursor(cursor, user_id=created_by_user_id, workspace_id=workspace_id)
                cursor.execute(
                    "SELECT 1 FROM vault_private.local_users WHERE user_id = %s AND status = 'active'",
                    (grantee_user_id,),
                )
                if cursor.fetchone() is None:
                    raise WorkspaceFileBadRequestError("That local user is unavailable.")
                share_id = str(uuid4())
                cursor.execute(
                    """
                    INSERT INTO vault_private.vault_workspace_folder_shares (
                      share_id, workspace_id, folder_path, folder_path_hash,
                      grantee_user_id, permission, created_by_user_id, status
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, 'active')
                    ON CONFLICT (workspace_id, folder_path_hash, grantee_user_id) DO UPDATE SET
                      permission = EXCLUDED.permission,
                      status = 'active',
                      revoked_at = NULL
                    RETURNING share_id
                    """,
                    (
                        share_id, workspace_id, normalized, workspace_file_key_hash(normalized),
                        grantee_user_id, permission, created_by_user_id,
                    ),
                )
                saved_id = str(cursor.fetchone()[0])
            connection.commit()
        share = self.get_share(share_id=saved_id)
        if share is None:
            raise WorkspaceFileNotFoundError("Workspace share could not be saved.")
        return share

    def revoke_share(self, *, workspace_id: str, share_id: str, actor_user_id: str) -> None:
        with psycopg.connect(self._database_url, connect_timeout=5) as connection:
            with connection.cursor() as cursor:
                self._require_owner_cursor(cursor, user_id=actor_user_id, workspace_id=workspace_id)
                cursor.execute(
                    """
                    UPDATE vault_private.vault_workspace_folder_shares
                    SET status = 'revoked', revoked_at = now()
                    WHERE share_id = %s AND workspace_id = %s AND status = 'active'
                    """,
                    (share_id, workspace_id),
                )
            connection.commit()

    @staticmethod
    def _get_projection_cursor(cursor: Any, *, workspace_id: str, file_key: str) -> WorkspaceFileProjection | None:
        normalized = normalize_workspace_file_key(file_key)
        cursor.execute(
            f"""
            SELECT {_PROJECTION_COLUMNS}
            FROM vault_private.vault_workspace_file_projections
            WHERE workspace_id = %s AND file_key_hash = %s AND file_key = %s
            """,
            (workspace_id, workspace_file_key_hash(normalized), normalized),
        )
        row = cursor.fetchone()
        return _row_to_projection(row) if row else None

    @staticmethod
    def _require_owner_cursor(cursor: Any, *, user_id: str, workspace_id: str) -> None:
        cursor.execute(
            """
            SELECT 1 FROM vault_private.local_workspace_memberships
            WHERE workspace_id = %s AND user_id = %s AND membership_type = 'owner'
              AND status = 'active'
            """,
            (workspace_id, user_id),
        )
        if cursor.fetchone() is None:
            from app.vault_runtime.workspace_files.errors import WorkspaceFileForbiddenError
            raise WorkspaceFileForbiddenError("Workspace owner access is required.")
