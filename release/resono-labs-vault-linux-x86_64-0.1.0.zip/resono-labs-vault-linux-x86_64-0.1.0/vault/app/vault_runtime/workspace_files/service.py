from __future__ import annotations

from dataclasses import dataclass, replace

from app.vault_runtime.local_identity.models import LocalPrincipal
from app.vault_runtime.workspace_files.errors import (
    WorkspaceFileForbiddenError,
    WorkspaceFileNotFoundError,
)
from app.vault_runtime.workspace_files.manager import WorkspaceFileManagerService, WorkspaceFileScope, WorkspaceFileUpload
from app.vault_runtime.workspace_files.models import (
    WorkspaceFileDirectory,
    WorkspaceFileEntry,
    WorkspaceFileMutation,
    WorkspaceFileRead,
    WorkspaceFolderShareView,
)
from app.vault_runtime.workspace_files.repository import WorkspaceFileRepository
from app.vault_runtime.workspace_paths import normalize_workspace_file_prefix


def _join_path(directory: str, name: str) -> str:
    return f"{directory}/{name}".strip("/") if directory else name


class WorkspaceFileService:
    def __init__(self, repository: WorkspaceFileRepository) -> None:
        self._repository = repository
        self._manager = WorkspaceFileManagerService(repository)

    def list_directory(
        self, *, principal: LocalPrincipal, directory: str | None, share_id: str | None = None,
    ) -> WorkspaceFileDirectory:
        scope = self._resolve_scope(principal=principal, share_id=share_id)
        actor = replace(principal, workspace_id=scope.workspace_id)
        mapped_directory = self._map_directory(scope=scope, directory=directory)
        listing = self._manager.list_directory(actor=actor, directory=mapped_directory or None)
        entries = [self._remap_entry(scope=scope, entry=entry) for entry in listing.entries]
        if share_id is None and not (directory or "").strip():
            for share in self._repository.list_shares_for_grantee(grantee_user_id=principal.user_id):
                label = share.folder_path.split("/")[-1] or share.folder_path
                owner = share.owner_display_name or "Vault user"
                entries.insert(
                    0,
                    WorkspaceFileEntry(
                        kind="directory",
                        name=f"{label} (shared)",
                        path=f"__share__/{share.share_id}",
                        childCount=None,
                        shared=True,
                        shareId=share.share_id,
                        sharedFrom=owner,
                        permission=share.permission,
                    ),
                )
        relative = (directory or "").strip("/")
        if scope.share_id:
            display = relative or (scope.share_root.split("/")[-1] if scope.share_root else "Shared folder")
            return WorkspaceFileDirectory(
                currentDirectory=display,
                parentDirectory=self._shared_parent(relative=relative),
                entries=entries,
                shareId=scope.share_id,
                permission=scope.permission,
            )
        return WorkspaceFileDirectory(
            currentDirectory=listing.currentDirectory,
            parentDirectory=listing.parentDirectory,
            entries=entries,
        )

    def read_file(self, *, principal: LocalPrincipal, file_key: str, share_id: str | None = None) -> WorkspaceFileRead:
        scope = self._resolve_scope(principal=principal, share_id=share_id, file_key=file_key)
        self._require_read(scope)
        actor = replace(principal, workspace_id=scope.workspace_id)
        return self._manager.read_file(actor=actor, file_key=self._map_path(scope=scope, file_key=file_key))

    def read_file_bytes(self, *, principal: LocalPrincipal, file_key: str, share_id: str | None = None) -> tuple[str, str, bytes]:
        scope = self._resolve_scope(principal=principal, share_id=share_id, file_key=file_key)
        self._require_read(scope)
        actor = replace(principal, workspace_id=scope.workspace_id)
        return self._manager.read_file_bytes(actor=actor, file_key=self._map_path(scope=scope, file_key=file_key))

    def save_file(self, *, principal: LocalPrincipal, file_key: str, content_markdown: str, share_id: str | None = None) -> WorkspaceFileMutation:
        scope = self._resolve_scope(principal=principal, share_id=share_id, file_key=file_key)
        self._require_write(scope)
        actor = replace(principal, workspace_id=scope.workspace_id)
        return self._manager.save_file(
            actor=actor,
            payload={"fileKey": self._map_path(scope=scope, file_key=file_key), "contentMarkdown": content_markdown},
        )

    def write_text_file(self, *, principal: LocalPrincipal, file_key: str, content_markdown: str = "", share_id: str | None = None) -> WorkspaceFileMutation:
        scope = self._resolve_scope(principal=principal, share_id=share_id, file_key=file_key)
        self._require_write(scope)
        actor = replace(principal, workspace_id=scope.workspace_id)
        return self._manager.write_text_file(
            actor=actor,
            file_key=self._map_path(scope=scope, file_key=file_key),
            content_markdown=content_markdown,
            overwrite_existing=False,
        )

    def create_directory(self, *, principal: LocalPrincipal, directory: str, share_id: str | None = None) -> WorkspaceFileMutation:
        scope = self._resolve_scope(principal=principal, share_id=share_id, file_key=directory)
        self._require_write(scope)
        actor = replace(principal, workspace_id=scope.workspace_id)
        return self._manager.create_directory(actor=actor, payload={"directory": self._map_path(scope=scope, file_key=directory)})

    def upload_files(
        self, *, principal: LocalPrincipal, directory: str | None, uploads: list[WorkspaceFileUpload], share_id: str | None = None,
    ) -> WorkspaceFileMutation:
        scope = self._resolve_scope(principal=principal, share_id=share_id, file_key=directory or "")
        self._require_write(scope)
        actor = replace(principal, workspace_id=scope.workspace_id)
        mapped_directory = self._map_directory(scope=scope, directory=directory)
        return self._manager.upload_files(actor=actor, directory=mapped_directory or None, uploads=uploads)

    def move_path(self, *, principal: LocalPrincipal, source_path: str, destination_path: str, share_id: str | None = None) -> WorkspaceFileMutation:
        scope = self._resolve_scope(principal=principal, share_id=share_id, file_key=source_path)
        self._require_write(scope)
        actor = replace(principal, workspace_id=scope.workspace_id)
        return self._manager.move_path(
            actor=actor,
            payload={
                "sourcePath": self._map_path(scope=scope, file_key=source_path),
                "destinationPath": self._map_path(scope=scope, file_key=destination_path),
            },
        )

    def delete_path(self, *, principal: LocalPrincipal, path: str, recursive: bool, share_id: str | None = None) -> WorkspaceFileMutation:
        scope = self._resolve_scope(principal=principal, share_id=share_id, file_key=path)
        self._require_write(scope)
        actor = replace(principal, workspace_id=scope.workspace_id)
        return self._manager.delete_path(actor=actor, payload={"path": self._map_path(scope=scope, file_key=path), "recursive": recursive})

    def list_shares(self, *, principal: LocalPrincipal, folder_path: str) -> list[WorkspaceFolderShareView]:
        shares = self._repository.list_shares_for_folder(
            workspace_id=principal.workspace_id,
            folder_path=folder_path,
            actor_user_id=principal.user_id,
        )
        return [
            WorkspaceFolderShareView(
                shareId=share.share_id,
                folderPath=share.folder_path,
                granteeUserId=share.grantee_user_id,
                granteeDisplayName=share.grantee_display_name or share.grantee_username or share.grantee_user_id,
                granteeUsername=share.grantee_username or "",
                permission=share.permission,
            )
            for share in shares
        ]

    def save_share(
        self, *, principal: LocalPrincipal, folder_path: str, grantee_user_id: str, permission: str,
    ) -> WorkspaceFolderShareView:
        share = self._repository.upsert_share(
            workspace_id=principal.workspace_id,
            folder_path=folder_path,
            grantee_user_id=grantee_user_id,
            permission=permission,
            created_by_user_id=principal.user_id,
        )
        return WorkspaceFolderShareView(
            shareId=share.share_id,
            folderPath=share.folder_path,
            granteeUserId=share.grantee_user_id,
            granteeDisplayName=share.grantee_display_name or share.grantee_username or share.grantee_user_id,
            granteeUsername=share.grantee_username or "",
            permission=share.permission,
        )

    def revoke_share(self, *, principal: LocalPrincipal, share_id: str) -> None:
        self._repository.revoke_share(
            workspace_id=principal.workspace_id,
            share_id=share_id,
            actor_user_id=principal.user_id,
        )

    def _resolve_scope(
        self, *, principal: LocalPrincipal, share_id: str | None, file_key: str = "",
    ) -> WorkspaceFileScope:
        if share_id:
            share = self._repository.get_share(share_id=share_id, grantee_user_id=principal.user_id)
            if share is None:
                raise WorkspaceFileNotFoundError("That shared folder is unavailable.")
            return WorkspaceFileScope(
                workspace_id=share.workspace_id,
                permission=share.permission,
                share_id=share.share_id,
                share_root=share.folder_path,
            )
        if file_key.startswith("__share__/"):
            nested = file_key.removeprefix("__share__/").split("/", 1)
            return self._resolve_scope(
                principal=principal,
                share_id=nested[0],
                file_key=nested[1] if len(nested) > 1 else "",
            )
        return WorkspaceFileScope(
            workspace_id=principal.workspace_id,
            permission="owner",
            share_id=None,
            share_root="",
        )

    def _map_directory(self, *, scope: WorkspaceFileScope, directory: str | None) -> str:
        relative = normalize_workspace_file_prefix(directory)
        if scope.share_id:
            return _join_path(scope.share_root, relative) if relative else scope.share_root
        return relative

    def _map_path(self, *, scope: WorkspaceFileScope, file_key: str, principal: LocalPrincipal | None = None) -> str:
        if file_key.startswith("__share__/"):
            parts = file_key.removeprefix("__share__/").split("/", 1)
            if principal is None:
                raise WorkspaceFileNotFoundError("That shared folder is unavailable.")
            nested = self._resolve_scope(principal=principal, share_id=parts[0])
            relative = parts[1] if len(parts) > 1 else ""
            return _join_path(nested.share_root, relative) if relative else nested.share_root
        relative = normalize_workspace_file_prefix(file_key) if file_key else ""
        if scope.share_id:
            return _join_path(scope.share_root, relative) if relative else scope.share_root
        return relative

    def _remap_entry(self, *, scope: WorkspaceFileScope, entry: WorkspaceFileEntry) -> WorkspaceFileEntry:
        if not scope.share_id or not scope.share_root:
            return entry
        prefix = f"{scope.share_root}/"
        path = entry.path
        if path == scope.share_root:
            relative = path.split("/")[-1] or path
        elif path.startswith(prefix):
            relative = path[len(prefix):]
        else:
            return entry
        return WorkspaceFileEntry(
            kind=entry.kind,
            name=entry.name,
            path=relative,
            sizeBytes=entry.sizeBytes,
            childCount=entry.childCount,
            mimeType=entry.mimeType,
            editable=entry.editable if scope.permission in {"owner", "write"} else False,
            projectionVersion=entry.projectionVersion,
            updatedAt=entry.updatedAt,
            shared=True,
            shareId=scope.share_id,
            permission=scope.permission,
        )

    @staticmethod
    def _shared_parent(*, relative: str) -> str | None:
        if not relative:
            return None
        parent = "/".join(relative.strip("/").split("/")[:-1])
        return parent or None

    @staticmethod
    def _require_read(scope: WorkspaceFileScope) -> None:
        if scope.permission in {"owner", "write", "read"}:
            return
        raise WorkspaceFileForbiddenError("Read access is required.")

    @staticmethod
    def _require_write(scope: WorkspaceFileScope) -> None:
        if scope.permission in {"owner", "write"}:
            return
        raise WorkspaceFileForbiddenError("Write access is required.")
