"""Atomic extension tree replacement adapted from R1 Plugin/Skill lifecycle."""

from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import shutil
from uuid import uuid4


class ExtensionFilesystemError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class InstalledTree:
    identity: str
    current: Path
    previous: Path | None


class ExtensionFilesystem:
    def __init__(self, root: Path) -> None:
        self._root = root.resolve()
        self._recovery = self._root / "recovery"

    def replace(self, *, category: str, identity: str, candidate_root: Path) -> InstalledTree:
        base = self._component_base(category, identity)
        source = candidate_root.resolve(strict=True)
        if not source.is_dir() or source == self._root or self._root.is_relative_to(source):
            raise ExtensionFilesystemError("candidate extension tree is invalid")
        base.mkdir(parents=True, exist_ok=True, mode=0o700)
        self._recovery.mkdir(parents=True, exist_ok=True, mode=0o700)
        operation_id = uuid4().hex
        staged = base / f".staged-{operation_id}"
        current = base / "current"
        previous = base / "previous"
        record = self._recovery / f"{operation_id}.json"
        shutil.copytree(source, staged, symlinks=False)
        _reject_links(staged)
        self._write_record(record, {
            "operationId": operation_id, "category": category, "identity": identity,
            "state": "staged", "hadCurrent": current.exists(),
        })
        try:
            if previous.exists():
                shutil.rmtree(previous)
            if current.exists():
                os.replace(current, previous)
            self._write_record(record, {
                "operationId": operation_id, "category": category, "identity": identity,
                "state": "previous-moved", "hadCurrent": previous.exists(),
            })
            os.replace(staged, current)
            self._write_record(record, {
                "operationId": operation_id, "category": category, "identity": identity,
                "state": "committed", "hadCurrent": previous.exists(),
            })
            record.unlink()
            return InstalledTree(identity, current, previous if previous.exists() else None)
        except Exception as exc:
            if not current.exists() and previous.exists():
                os.replace(previous, current)
            shutil.rmtree(staged, ignore_errors=True)
            raise ExtensionFilesystemError("extension replacement failed and was rolled back") from exc

    def rollback(self, *, category: str, identity: str) -> InstalledTree:
        base = self._component_base(category, identity)
        current, previous = base / "current", base / "previous"
        if not previous.is_dir():
            raise ExtensionFilesystemError("no previous extension version exists")
        displaced = base / f".rollback-{uuid4().hex}"
        if current.exists():
            os.replace(current, displaced)
        try:
            os.replace(previous, current)
            if displaced.exists():
                os.replace(displaced, previous)
        except Exception as exc:
            if not current.exists() and displaced.exists():
                os.replace(displaced, current)
            raise ExtensionFilesystemError("extension rollback failed") from exc
        return InstalledTree(identity, current, previous if previous.exists() else None)

    def recover(self) -> tuple[str, ...]:
        if not self._recovery.exists():
            return ()
        recovered: list[str] = []
        for record in sorted(self._recovery.glob("*.json")):
            try:
                data = json.loads(record.read_text(encoding="utf-8"))
                base = self._component_base(str(data["category"]), str(data["identity"]))
                current, previous = base / "current", base / "previous"
                staged = base / f".staged-{data['operationId']}"
                if not current.exists() and previous.exists():
                    os.replace(previous, current)
                shutil.rmtree(staged, ignore_errors=True)
                record.unlink()
                recovered.append(str(data["operationId"]))
            except Exception as exc:
                raise ExtensionFilesystemError(f"cannot recover extension operation {record.name}") from exc
        return tuple(recovered)

    def remove(self, *, category: str, identity: str) -> None:
        base = self._component_base(category, identity)
        shutil.rmtree(base, ignore_errors=True)

    def _component_base(self, category: str, identity: str) -> Path:
        if category not in {"plugins", "skills"}:
            raise ExtensionFilesystemError("unsupported extension category")
        if not re.fullmatch(r"[a-z0-9](?:[a-z0-9._-]*[a-z0-9])?", identity) or ".." in identity:
            raise ExtensionFilesystemError("extension identity is unsafe")
        base = (self._root / category / identity).resolve()
        if not base.is_relative_to(self._root):
            raise ExtensionFilesystemError("extension path escapes its root")
        return base

    @staticmethod
    def _write_record(path: Path, value: dict[str, object]) -> None:
        temporary = path.with_suffix(".tmp")
        temporary.write_text(json.dumps(value, sort_keys=True), encoding="utf-8")
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)


def _reject_links(root: Path) -> None:
    for path in root.rglob("*"):
        if path.is_symlink():
            raise ExtensionFilesystemError("extension tree contains a link")
