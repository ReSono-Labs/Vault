"""Owner-controlled Plugin/Skill lifecycle assembled from the frozen Voice/R1 donors."""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path

from app.vault_runtime.extensions.archives import ArchiveInspector, QuarantinedArchive
from app.vault_runtime.extensions.filesystem import ExtensionFilesystem
from app.vault_runtime.extensions.models import ExtensionAudience, ExtensionKind, ExtensionState
from app.vault_runtime.extensions.package_review import PackageReview, review_plugin_package
from app.vault_runtime.extensions.preflight import Preflight, PreflightRegistry
from app.vault_runtime.extensions.repository import ExtensionRecord, ExtensionRepository
from app.vault_runtime.extensions.skills import SkillDocument, SkillSpecificationError, parse_skill
from app.vault_runtime.extensions.specification import (
    McpServer, PluginManifest, PluginSpecificationError, parse_mcp_bytes,
    parse_mcp_document_partial, parse_plugin_manifest,
)
from app.vault_runtime.extensions.vault_manifest import VaultPluginManifest, parse_vault_manifest


@dataclass(frozen=True, slots=True)
class SkillCandidate:
    archive: QuarantinedArchive
    document: SkillDocument


@dataclass(frozen=True, slots=True)
class PluginCandidate:
    archive: QuarantinedArchive
    manifest: PluginManifest
    skills: tuple[tuple[str, SkillDocument, str], ...]
    mcp_servers: tuple[McpServer, ...]
    diagnostics: tuple[str, ...] = ()
    review: PackageReview | None = None
    vault_manifest: VaultPluginManifest | None = None
    configuration_schema: dict[str, object] | None = None


@dataclass(frozen=True, slots=True)
class McpCandidate:
    server: McpServer
    content_hash: str


class ExtensionImportService:
    def __init__(
        self, *, repository: ExtensionRepository, inspector: ArchiveInspector,
        filesystem: ExtensionFilesystem,
    ) -> None:
        self._repository = repository
        self._inspector = inspector
        self._filesystem = filesystem
        self._skill_preflights: PreflightRegistry[SkillCandidate] = PreflightRegistry(
            dispose=lambda candidate: candidate.archive.discard()
        )
        self._plugin_preflights: PreflightRegistry[PluginCandidate] = PreflightRegistry(
            dispose=lambda candidate: candidate.archive.discard()
        )
        self._mcp_preflights: PreflightRegistry[McpCandidate] = PreflightRegistry()

    def preflight_skill(
        self, payload: bytes, filename: str, *, actor_user_id: str,
        workspace_id: str, audience: ExtensionAudience,
    ) -> Preflight[SkillCandidate]:
        archive = self._inspector.inspect(payload, filename, required_root_file="SKILL.md")
        try:
            document = parse_skill(archive.content_root)
            current = self._repository.get(
                user_id=actor_user_id, workspace_id=workspace_id,
                kind=ExtensionKind.SKILL, identity=document.name, owner=True,
            )
            return self._skill_preflights.issue(
                kind=ExtensionKind.SKILL, identity=document.name,
                principal_user_id=actor_user_id, workspace_id=workspace_id,
                candidate_hash=archive.content_hash,
                current_hash=current.content_hash if current else None,
                audience=audience, payload=SkillCandidate(archive, document),
            )
        except Exception:
            archive.discard()
            raise

    def confirm_skill(
        self, token: str, *, actor_user_id: str, workspace_id: str, replace: bool,
    ) -> ExtensionRecord:
        preview = self._repository_current_from_preflight(
            token, actor_user_id, workspace_id, self._skill_preflights, ExtensionKind.SKILL,
            replace=replace,
        )
        candidate = preview.payload
        installed_before = preview.current_hash is not None
        try:
            self._filesystem.replace(category="skills", identity=preview.identity, candidate_root=candidate.archive.content_root)
            record = self._repository.install(
                actor_user_id=actor_user_id, workspace_id=workspace_id,
                kind=ExtensionKind.SKILL, identity=candidate.document.name,
                display_name=candidate.document.name, version=candidate.document.metadata.get("version"),
                description=candidate.document.description, content_hash=candidate.archive.content_hash,
                configuration={"audience": sorted(agent.value for agent in preview.audience.agents)},
            )
            return record
        except Exception:
            if installed_before:
                self._filesystem.rollback(category="skills", identity=preview.identity)
            else:
                self._filesystem.remove(category="skills", identity=preview.identity)
            raise
        finally:
            candidate.archive.discard()

    def preflight_plugin(
        self, payload: bytes, filename: str, *, actor_user_id: str,
        workspace_id: str, audience: ExtensionAudience,
    ) -> Preflight[PluginCandidate]:
        archive = self._inspector.inspect(payload, filename, required_root_file="plugin.json")
        try:
            manifest = parse_plugin_manifest(archive.content_root / "plugin.json")
            vault_manifest, configuration_schema = parse_vault_manifest(archive.content_root)
            diagnostics = list(manifest.diagnostics)
            review = review_plugin_package(archive.content_root)
            diagnostics.extend(review.diagnostics)
            skills: list[tuple[str, SkillDocument, str]] = []
            skill_root = archive.content_root / "skills"
            if skill_root.exists():
                if not skill_root.is_dir():
                    diagnostics.append("skills: fixed component location is not a directory")
                else:
                    for child in sorted(skill_root.iterdir()):
                        if not child.is_dir():
                            diagnostics.append(f"skill:{child.name}: entry is not a directory")
                            continue
                        try:
                            skills.append((child.name, parse_skill(child), _directory_hash(child)))
                        except SkillSpecificationError as exc:
                            diagnostics.append(f"skill:{child.name}: {exc}")
            mcp_path = archive.content_root / "mcp.json"
            servers: tuple[McpServer, ...] = ()
            if mcp_path.exists():
                if not mcp_path.is_file():
                    diagnostics.append("mcp: fixed component location is not a file")
                else:
                    try:
                        mcp = parse_mcp_document_partial(mcp_path)
                        servers = mcp.servers
                        diagnostics.extend(mcp.diagnostics)
                    except PluginSpecificationError as exc:
                        diagnostics.append(f"mcp: {exc}")
            current = self._repository.get(
                user_id=actor_user_id, workspace_id=workspace_id,
                kind=ExtensionKind.PLUGIN, identity=manifest.name, owner=True,
            )
            candidate = PluginCandidate(
                archive, manifest, tuple(skills), tuple(servers), tuple(diagnostics), review,
                vault_manifest, configuration_schema,
            )
            return self._plugin_preflights.issue(
                kind=ExtensionKind.PLUGIN, identity=manifest.name,
                principal_user_id=actor_user_id, workspace_id=workspace_id,
                candidate_hash=archive.content_hash,
                current_hash=current.content_hash if current else None,
                audience=audience, payload=candidate,
            )
        except Exception:
            archive.discard()
            raise

    def confirm_plugin(
        self, token: str, *, actor_user_id: str, workspace_id: str, replace: bool,
    ) -> ExtensionRecord:
        preview = self._repository_current_from_preflight(
            token, actor_user_id, workspace_id, self._plugin_preflights, ExtensionKind.PLUGIN,
            replace=replace,
        )
        candidate = preview.payload
        installed_before = preview.current_hash is not None
        components = tuple(("skill", name, digest) for name, _document, digest in candidate.skills)
        components += tuple(("mcp", server.name, _value_hash(server.configuration)) for server in candidate.mcp_servers)
        try:
            self._filesystem.replace(category="plugins", identity=preview.identity, candidate_root=candidate.archive.content_root)
            record = self._repository.install(
                actor_user_id=actor_user_id, workspace_id=workspace_id,
                kind=ExtensionKind.PLUGIN, identity=candidate.manifest.name,
                display_name=candidate.manifest.name, version=candidate.manifest.version,
                description=candidate.manifest.description, content_hash=candidate.archive.content_hash,
                configuration={
                    "audience": sorted(agent.value for agent in preview.audience.agents),
                    "vaultManifest": {
                        "minimumVaultVersion": candidate.vault_manifest.minimum_version,
                        "agents": sorted(agent.value for agent in candidate.vault_manifest.agents),
                        "services": list(candidate.vault_manifest.services),
                    } if candidate.vault_manifest else None,
                    "configurationSchema": candidate.configuration_schema,
                    "settings": {},
                },
                components=components,
            )
            reconcile = getattr(self._repository, "reconcile_managed_mcp", None)
            if reconcile is not None:
                reconcile(
                    actor_user_id=actor_user_id, workspace_id=workspace_id,
                    plugin=record,
                    servers=tuple((
                        server.name,
                        _value_hash(server.configuration),
                        {
                            "transport": server.validated.transport,
                            "url": server.validated.endpoint,
                            "headers": dict(server.validated.headers),
                            "executable": server.validated.executable,
                        },
                    ) for server in candidate.mcp_servers),
                )
            return record
        except Exception:
            if installed_before:
                self._filesystem.rollback(category="plugins", identity=preview.identity)
            else:
                self._filesystem.remove(category="plugins", identity=preview.identity)
            raise
        finally:
            candidate.archive.discard()

    def preflight_mcp(
        self, payload: bytes, *, actor_user_id: str, workspace_id: str,
        audience: ExtensionAudience,
    ) -> tuple[Preflight[McpCandidate], ...]:
        servers = parse_mcp_bytes(payload)
        previews: list[Preflight[McpCandidate]] = []
        try:
            for server in servers:
                content_hash = _value_hash(server.configuration)
                current = self._repository.get(
                    user_id=actor_user_id, workspace_id=workspace_id,
                    kind=ExtensionKind.MCP, identity=server.name, owner=True,
                )
                previews.append(self._mcp_preflights.issue(
                    kind=ExtensionKind.MCP, identity=server.name,
                    principal_user_id=actor_user_id, workspace_id=workspace_id,
                    candidate_hash=content_hash,
                    current_hash=current.content_hash if current else None,
                    audience=audience, payload=McpCandidate(server, content_hash),
                ))
            return tuple(previews)
        except Exception:
            for preview in previews:
                self._mcp_preflights.discard(preview.token)
            raise

    def confirm_mcp(
        self, token: str, *, actor_user_id: str, workspace_id: str, replace: bool,
    ) -> ExtensionRecord:
        preview = self._repository_current_from_preflight(
            token, actor_user_id, workspace_id, self._mcp_preflights,
            ExtensionKind.MCP, replace=replace,
        )
        candidate = preview.payload
        return self._repository.install(
            actor_user_id=actor_user_id, workspace_id=workspace_id,
            kind=ExtensionKind.MCP, identity=candidate.server.name,
            display_name=candidate.server.name, version=None,
            description="MCP connection", content_hash=candidate.content_hash,
            configuration={
                "transport": candidate.server.validated.transport,
                "endpoint": candidate.server.validated.endpoint,
                "headers": dict(candidate.server.validated.headers),
                "executable": candidate.server.validated.executable,
            },
        )

    def set_state(
        self, *, actor_user_id: str, workspace_id: str,
        extension_id: str, state: ExtensionState,
    ) -> ExtensionRecord:
        current = self._repository.by_id(
            actor_user_id=actor_user_id, workspace_id=workspace_id,
            extension_id=extension_id, owner=True,
        )
        record = self._repository.set_state(
            actor_user_id=actor_user_id, workspace_id=workspace_id,
            extension_id=extension_id, state=state,
        )
        if current.kind is ExtensionKind.PLUGIN:
            set_managed_state = getattr(self._repository, "set_managed_state", None)
            if set_managed_state is not None:
                set_managed_state(
                    actor_user_id=actor_user_id, workspace_id=workspace_id,
                    plugin_id=current.extension_id, state=state,
                )
        if state is ExtensionState.REMOVED and current.kind in {ExtensionKind.SKILL, ExtensionKind.PLUGIN}:
            category = "skills" if current.kind is ExtensionKind.SKILL else "plugins"
            self._filesystem.remove(category=category, identity=current.identity)
        return record

    def _repository_current_from_preflight(
        self, token: str, actor_user_id: str, workspace_id: str,
        registry: PreflightRegistry, kind: ExtensionKind, *, replace: bool = False,
    ) -> Preflight:
        record = registry.peek(token)
        current = self._repository.get(
            user_id=actor_user_id, workspace_id=workspace_id, kind=kind,
            identity=record.identity, owner=True,
        )
        return registry.consume(
            token, principal_user_id=actor_user_id, workspace_id=workspace_id,
            current_hash=current.content_hash if current else None, replace=replace,
        )


def _directory_hash(root: Path) -> str:
    digest = sha256()
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        relative = path.relative_to(root).as_posix().encode()
        digest.update(relative); digest.update(b"\0"); digest.update(path.read_bytes())
    return digest.hexdigest()


def _value_hash(value: object) -> str:
    import json
    return sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
