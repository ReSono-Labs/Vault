from __future__ import annotations

from collections.abc import Callable
from typing import Any
from uuid import uuid4

import httpx

from app.vault_runtime.voice.provider import (
    ProviderCredential,
    ProviderDescriptor,
    RealtimeSessionRequest,
    RealtimeSessionResult,
)

RealtimeJSONTransport = Callable[[str, dict[str, str], dict[str, Any]], dict[str, Any]]


class OpenAIRealtimeError(RuntimeError):
    code = "openai_realtime_error"


class OpenAIRealtimeProvider:
    """Bounded Voice donor adapter using an owner-supplied OpenAI credential."""

    provider_key = "openai"
    descriptor = ProviderDescriptor(
        provider_key="openai", display_name="OpenAI", connection_mode="webrtc",
        protocol="openai-realtime", default_voice_model="gpt-realtime-2.1",
        default_text_model="gpt-5.6-sol", default_voice="marin",
        voices=("marin", "cedar", "alloy", "ash", "ballad", "coral", "echo", "sage", "shimmer", "verse"),
        voice_models=("gpt-realtime-2.1", "gpt-realtime-2.1-mini"),
    )

    def __init__(
        self,
        *,
        base_url: str = "https://api.openai.com/v1",
        organization: str | None = None,
        json_transport: RealtimeJSONTransport | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._organization = organization.strip() if organization else None
        self._transport = json_transport or self._default_transport

    def create_realtime_session(
        self, request: RealtimeSessionRequest, *, credential: ProviderCredential
    ) -> RealtimeSessionResult:
        if request.connection_mode != "webrtc":
            raise OpenAIRealtimeError("Browser client-secret creation requires WebRTC mode.")
        if credential.auth_method == "chatgpt_oauth":
            return self._create_chatgpt_session(request, credential)
        url = f"{self._base_url}/realtime/client_secrets"
        headers = {
            "Authorization": f"Bearer {credential.value}",
            "Content-Type": "application/json",
        }
        if self._organization:
            headers["OpenAI-Organization"] = self._organization
        session = build_openai_realtime_session_object(request)
        try:
            response = self._transport(url, headers, {"session": session})
        except httpx.HTTPError as exc:
            raise OpenAIRealtimeError("OpenAI Realtime client-secret request failed.") from exc
        client_secret = response.get("value")
        if not isinstance(client_secret, str) or not client_secret:
            secret_object = response.get("client_secret")
            if isinstance(secret_object, dict):
                client_secret = secret_object.get("value")
        if not isinstance(client_secret, str) or not client_secret:
            raise OpenAIRealtimeError("OpenAI Realtime response did not contain a client secret.")
        expires_at = response.get("expires_at")
        provider_session_id = response.get("id")
        if not isinstance(provider_session_id, str) or not provider_session_id:
            provider_session_id = f"openai-local-request-{uuid4()}"
        return RealtimeSessionResult(
            provider_key=self.provider_key,
            model_key=request.model_key,
            connection_mode=request.connection_mode,
            provider_session_id=provider_session_id,
            session_update_event={"type": "session.update", "session": session},
            client_secret=client_secret,
            expires_at=expires_at if isinstance(expires_at, int) else None,
        )

    def _create_chatgpt_session(
        self, request: RealtimeSessionRequest, credential: ProviderCredential,
    ) -> RealtimeSessionResult:
        offer = request.offer_sdp or ""
        if not offer.startswith("v=0"):
            raise OpenAIRealtimeError("ChatGPT OAuth Voice requires a WebRTC offer.")
        session: dict[str, object] = {
            "audio": {"output": {"voice": "sol"}},
            "delegation": {"ack_filler": False, "type": "client"},
            "model": "gpt-live-1-codex",
        }
        if request.instructions:
            session["instructions"] = request.instructions
        try:
            response = httpx.post(
                "https://chatgpt.com/backend-api/codex/realtime/calls",
                params={"intent": "quicksilver", "architecture": "avas"},
                headers={
                    "Authorization": f"Bearer {credential.value}",
                    "OpenAI-Alpha": "quicksilver=v2", "x-session-id": str(uuid4()),
                    "Origin": "https://chatgpt.com", "Referer": "https://chatgpt.com/",
                },
                json={"sdp": offer, "session": session}, timeout=30.0,
            )
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise OpenAIRealtimeError("ChatGPT OAuth Voice session failed.") from exc
        answer = response.text.strip()
        if not answer.startswith("v=0"):
            try:
                body = response.json()
                answer = str(body.get("sdp") or body.get("answer") or "")
            except Exception:
                answer = ""
        if not answer.startswith("v=0"):
            raise OpenAIRealtimeError("ChatGPT OAuth Voice returned an invalid answer.")
        return RealtimeSessionResult(
            provider_key=self.provider_key, model_key=request.model_key,
            connection_mode=request.connection_mode,
            provider_session_id=f"chatgpt-oauth-{uuid4()}",
            session_update_event={}, sdp_answer=answer + ("" if answer.endswith("\n") else "\r\n"),
            protocol="openai-realtime",
        )

    @staticmethod
    def _default_transport(
        url: str, headers: dict[str, str], payload: dict[str, Any]
    ) -> dict[str, Any]:
        response = httpx.post(url, headers=headers, json=payload, timeout=30.0)
        response.raise_for_status()
        data = response.json()
        if not isinstance(data, dict):
            raise OpenAIRealtimeError("OpenAI Realtime response was not an object.")
        return data


def build_openai_realtime_session_object(request: RealtimeSessionRequest) -> dict[str, Any]:
    modalities = tuple(dict.fromkeys(request.output_modalities))
    if not modalities or any(value not in {"audio", "text"} for value in modalities):
        raise OpenAIRealtimeError("Realtime output modalities are invalid.")
    session: dict[str, Any] = {
        "type": "realtime",
        "model": request.model_key,
        "output_modalities": list(modalities),
    }
    if request.instructions:
        session["instructions"] = request.instructions
    audio_input: dict[str, Any] = {}
    if request.audio_format and request.audio_rate:
        audio_input["format"] = {"type": request.audio_format, "rate": request.audio_rate}
    if request.input_noise_reduction_type:
        audio_input["noise_reduction"] = {"type": request.input_noise_reduction_type}
    if request.input_audio_transcription_model:
        audio_input["transcription"] = {"model": request.input_audio_transcription_model}
    if request.turn_detection_type:
        turn_detection: dict[str, Any] = {"type": request.turn_detection_type}
        if request.turn_detection_create_response is not None:
            turn_detection["create_response"] = request.turn_detection_create_response
        if request.turn_detection_interrupt_response is not None:
            turn_detection["interrupt_response"] = request.turn_detection_interrupt_response
        if request.turn_detection_threshold is not None:
            turn_detection["threshold"] = request.turn_detection_threshold
        if request.turn_detection_prefix_padding_ms is not None:
            turn_detection["prefix_padding_ms"] = request.turn_detection_prefix_padding_ms
        if request.turn_detection_silence_duration_ms is not None:
            turn_detection["silence_duration_ms"] = request.turn_detection_silence_duration_ms
        audio_input["turn_detection"] = turn_detection
    audio: dict[str, Any] = {}
    if audio_input:
        audio["input"] = audio_input
    if request.voice:
        output: dict[str, Any] = {"voice": request.voice}
        if request.audio_format and request.audio_rate:
            output["format"] = {"type": request.audio_format, "rate": request.audio_rate}
        audio["output"] = output
    if audio:
        session["audio"] = audio
    if request.tool_definitions:
        session["tools"] = [
            {
                "type": "function",
                "name": str(tool["name"]),
                "description": str(tool["description"]),
                "parameters": tool["parameters"],
            }
            for tool in request.tool_definitions
        ]
    if request.tool_choice:
        session["tool_choice"] = request.tool_choice
    return session
